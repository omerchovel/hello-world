from flask import Flask, redirect, url_for, render_template
from flask import request
from flask import session
from flask import Blueprint
import mysql.connector

mission10 = Blueprint('mission10', __name__, static_folder='static', static_url_path='/mission10',
                      template_folder='templates')

#app = Flask(__name__)

def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', password='root', database='mission10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        # insert update delete
        connection.commit()
        return_value = True

    if query_type == 'fetch':
        # select
        query_result = cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value


@app.route('/users')
def users():
    query = "select * from users"
    query_result = interact_db(query=query, query_type='fetch')
    return render_template('users.html', users=query_result)

@app.route('/insertUser', methods=['GET', 'POST'])
def insert():
    if request.method == 'POST':
        name = request.form['name']
        mail = request.form['mail']
        query = "INSERT INTO users(name,mail) VALUES ('%s', '%s')" % (name, mail)
        interact_db(query=query, query_type='commit')
        return redirect('/users')
    return render_template('insertUser.html', req_method=request.method)

@app.route('/deleteUser', methods=['GET', 'POST'])
def deleteUs():
    if request.method == 'POST':
        id = request.form['id']
        query = "DELETE FROM users WHERE id='%s';" % (id)
        interact_db(query=query, query_type='commit')
        return redirect('/users')
    return render_template('deleteUser.html', req_method=request.method)

@app.route('/UpdateUser', methods=['GET', 'POST'])
def update():
    if request.method == 'POST':
        id = request.form['id']
        name = request.form['name']
        mail = request.form['mail']
        query = "UPDATE users SET name = '%s', mail = '%s' WHERE id = '%s';" % (name, mail, id)
        interact_db(query=query, query_type='commit')
        return redirect('/users')
    return render_template('UpdateUser.html', req_method=request.method)

@app.route('/')
def hello_world():
    return users()




#if __name__ == '__main__':
#    app.run(debug=True)
