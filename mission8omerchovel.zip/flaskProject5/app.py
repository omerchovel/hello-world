from flask import Flask, redirect, render_template, url_for

app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template('main.html')

@app.route('/people')
def hello_world1():
    return render_template('hw7omercho.html')

@app.route('/hobbies')
def hello_world2():
    user1 = {'name': 'omer'}
    return render_template('assignment8.html', user=user1, pets= ['dog', 'cat',' ferret', 'perrot'])

if __name__ == '__main__':
    app.run(debug=True)
