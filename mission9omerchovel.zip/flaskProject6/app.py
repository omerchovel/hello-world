from flask import Flask, redirect, url_for, render_template
from flask import request, session
import flask

app = Flask(__name__)


@app.route('/mission9', methods=['GET','POST'])
def ex_func():
    username = ''
    if request.method == 'POST':
        username = request.form['username']
        return render_template('mission9.html', request_method=request.method, username=username)



@app.route('/all_users')
def all_users_func():
    return render_template('all_users.html')

@app.route('/Michael_Lawson')
def Michael_Lawson_func():
    return render_template('Michael_Lawson.html')

@app.route('/Lindsay_Ferguson')
def Lindsay_Ferguson_func():
    return render_template('Lindsay_Ferguson.html')

@app.route('/Tobias_Funke')
def Tobias_Funke_func():
    return render_template('Tobias_Funke.html')

@app.route('/Byron_Fields')
def Byron_Fields_func():
    return render_template('Byron_Fields.html')

@app.route('/George_Edwards')
def George_Edwards_func():
    return render_template('George_Edwards.html')

@app.route('/Rachel_Howell')
def Rachel_Howell_func():
    return render_template('Rachel_Howell.html')




@app.route('/catalog')
def catalog_func():
    if 'name' in request.args:
        curr_id = request.args['name']
        if curr_id == 'Michael Lawson':
            return Michael_Lawson_func()
        if curr_id == 'Lindsay Ferguson':
            return Lindsay_Ferguson_func()
        if curr_id == 'Tobias Funke':
            return Tobias_Funke_func()
        if curr_id == 'Byron Fields':
            return Byron_Fields_func()
        if curr_id == 'George Edwards':
            return George_Edwards_func()
        if curr_id == 'Rachel Howell':
            return Rachel_Howell_func()
        return all_users_func()

    if 'email' in request.args:
        curr_mail = request.args['email']
        if curr_mail == 'michael.lawson@reqres.in':
            return Michael_Lawson_func()
        if curr_mail == 'lindsay.ferguson@reqres.in':
            return Lindsay_Ferguson_func()
        if curr_mail == 'tobias.funke@reqres.in':
            return Tobias_Funke_func()
        if curr_mail == 'byron.fields@reqres.in':
            return Byron_Fields_func()
        if curr_mail == 'george.edwards@reqres.in':
            return George_Edwards_func()
        if curr_mail == 'rachel.howell@reqres.in':
            return Rachel_Howell_func()
        return all_users_func()
    return all_users_func()

@app.route('/')
def hello_world():
    return render_template('mission9.html')


if __name__ == '__main__':
    app.run(debug=True)
